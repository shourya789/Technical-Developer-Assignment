<?php
/**
 * Plugin Name: Custom User List & Greeting
 * Description: Adds an admin page to display registered users and a shortcode for a dynamic greeting message.
 * Version: 1.0
 * Author: Shourya Gupta
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Add Admin Menu Page
function custom_user_list_menu() {
    add_menu_page('User List', 'User List', 'manage_options', 'custom-user-list', 'custom_user_list_page');
}
add_action('admin_menu', 'custom_user_list_menu');

// Display User List
function custom_user_list_page() {
    echo '<h2>Registered Users</h2>';
    echo '<table border="1" cellspacing="0" cellpadding="5">';
    echo '<tr><th>ID</th><th>Name</th><th>Email</th><th>Registered Date</th></tr>';
    
    $users = get_users();
    foreach ($users as $user) {
        echo '<tr>';
        echo '<td>' . esc_html($user->ID) . '</td>';
        echo '<td>' . esc_html($user->display_name) . '</td>';
        echo '<td>' . esc_html($user->user_email) . '</td>';
        echo '<td>' . esc_html($user->user_registered) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}

// Greeting Shortcode
function custom_greeting_shortcode() {
    $hour = date('G');
    if ($hour < 12) {
        $greeting = 'Good Morning, Visitor!';
    } elseif ($hour < 18) {
        $greeting = 'Good Afternoon, Visitor!';
    } else {
        $greeting = 'Good Evening, Visitor!';
    }
    return '<p>' . esc_html($greeting) . '</p>';
}
add_shortcode('custom_greeting', 'custom_greeting_shortcode');
