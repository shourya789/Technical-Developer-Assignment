import Foundation

struct Product: Identifiable, Codable {
    let id: Int
    let title: String
    let image: String
    let description: String
}
