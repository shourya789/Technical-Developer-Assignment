import Foundation

class ProductViewModel: ObservableObject {
    @Published var products: [Product] = []

    init() {
        loadProducts()
    }

    func loadProducts() {
        if let url = Bundle.main.url(forResource: "products", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let decodedData = try? JSONDecoder().decode([Product].self, from: data) {
            self.products = decodedData
        }
    }
}
