import requests
import json
import logging
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(filename='shopify_api.log', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Shopify API credentials
SHOPIFY_STORE_URL = os.getenv("SHOPIFY_STORE_URL")
SHOPIFY_ADMIN_API_TOKEN = os.getenv("SHOPIFY_ADMIN_API_TOKEN")  # Corrected token usage
SHOPIFY_API_VERSION = os.getenv("SHOPIFY_API_VERSION")

SHOPIFY_PRODUCT_API_ENDPOINT = f"{SHOPIFY_STORE_URL}/admin/api/{SHOPIFY_API_VERSION}/products.json"

# FakeStoreAPI URL (Placeholder for Amazon API)
FAKESTORE_API_URL = "https://fakestoreapi.com/products/1"

def fetch_product_data():
    """Fetch product data from FakeStoreAPI."""
    try:
        response = requests.get(FAKESTORE_API_URL)
        response.raise_for_status()
        product = response.json()
        logging.info("Fetched product data successfully.")

        return {
            "title": product.get("title", "Default Title"),
            "body_html": product.get("description", "No description available."),
            "vendor": "Fake Store",
            "product_type": "General",
            "variants": [{
                "price": str(product.get("price", "0.00")),
                "sku": str(product.get("id", "0000"))
            }]
        }
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching product data: {e}")
        return None

def create_shopify_product(product_data):
    """Create a product in Shopify using the Admin API."""
    headers = {
    "Content-Type": "application/json",
    "X-Shopify-Access-Token": os.getenv("SHOPIFY_ADMIN_API_TOKEN")  # ✅ Secure way
}


    payload = {"product": product_data}

    try:
        response = requests.post(SHOPIFY_PRODUCT_API_ENDPOINT, json=payload, headers=headers)
        response.raise_for_status()
        logging.info("Product successfully added to Shopify.")
        print("Shopify API Response:", response.json())  # Debug response
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"Error adding product to Shopify: {e}")
        print("Error Response:", response.text)  # Print API response for debugging
        return None

if __name__ == "__main__":
    product_data = fetch_product_data()
    if product_data:
        result = create_shopify_product(product_data)
        if result:
            print("Product successfully added to Shopify:", result)
        else:
            print("Failed to add product. Check shopify_api.log for details.")
